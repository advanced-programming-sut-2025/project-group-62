package models.Building;

public class Barn {
}
