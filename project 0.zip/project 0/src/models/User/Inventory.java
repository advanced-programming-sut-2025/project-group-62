package models.User;

import models.Tool.Tool;

import java.util.ArrayList;

public class Inventory {
    private final ArrayList<Tool> tools=new ArrayList<>();
}
