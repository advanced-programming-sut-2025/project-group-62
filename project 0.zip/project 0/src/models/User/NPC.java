package models.User;

public class NPC {
    private String name;
    private int friendship;
}
