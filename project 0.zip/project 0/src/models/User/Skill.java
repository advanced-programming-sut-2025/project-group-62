package models.User;

public class Skill {
    private int mining;
    private int forging;
    private int fishing;
    private int farming;

    public int getMining() {
        return mining;
    }
    public int getForging() {
        return forging;
    }
    public int getFishing() {
        return fishing;
    }
    public int getFarming() {
        return farming;
    }
}
