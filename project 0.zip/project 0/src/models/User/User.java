package models.User;

import models.Game;

import java.util.ArrayList;

public class User {
    private final ArrayList<Game> games=new ArrayList<>();
    private String username;
    private String password;
    private String email;
}
