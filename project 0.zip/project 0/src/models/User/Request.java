package models.User;

public class Request {
    private Item reward;
    private Item request;
}
