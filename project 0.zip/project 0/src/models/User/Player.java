package models.User;

import models.Animal.Animal;
import models.Enums.Recipe;
import models.Tool.Tool;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Player {
    private User user;
    private int energy;
    private int xPosition;
    private int yPosition;
    private Tool tool;
    private final ArrayList<Animal> allAnimals=new ArrayList<>();
    private final ArrayList<Recipe> allRecipes=new ArrayList<>();
    public Player(User user){
        this.user = user;
    }
    public void setTool(Tool tool){
        this.tool = tool;
    }
    Skill skill;
    public void cook(){}
    public void trade(){}
    public void craft(){}
}
