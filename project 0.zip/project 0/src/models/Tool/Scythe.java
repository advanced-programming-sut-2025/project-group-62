package models.Tool;

public class Scythe extends Tool{
}
