package models.Tool;

public class Milkpail extends Tool{
}
