package models.Tool;

public class Shear extends Tool{
}
