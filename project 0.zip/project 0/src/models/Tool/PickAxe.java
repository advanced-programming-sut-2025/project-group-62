package models.Tool;

public class PickAxe extends Tool{
}
