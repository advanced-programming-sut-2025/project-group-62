package models.Tool;

public class Backpack extends Tool{
}
