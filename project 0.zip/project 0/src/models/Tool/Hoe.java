package models.Tool;

public class Hoe extends Tool{
}
