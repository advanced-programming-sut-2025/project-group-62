package models.Tool;

public class FishingPole extends Tool{
}
