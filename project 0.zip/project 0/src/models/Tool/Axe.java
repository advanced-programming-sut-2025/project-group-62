package models.Tool;

public class Axe extends Tool{
}
