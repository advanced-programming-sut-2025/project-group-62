package models.Tool;

public class WateringCan extends Tool{
}
