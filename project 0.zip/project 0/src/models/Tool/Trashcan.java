package models.Tool;

public class Trashcan extends Tool{
}
