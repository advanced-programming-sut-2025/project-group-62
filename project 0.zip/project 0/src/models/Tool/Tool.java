package models.Tool;

import models.Enums.TypeOfTools;

public abstract class Tool {
    private int durability;
    private int level;
    private TypeOfTools type;
    public void useTool(){

    }
    public void decreaseDurability(){
        durability--;
    }
}
