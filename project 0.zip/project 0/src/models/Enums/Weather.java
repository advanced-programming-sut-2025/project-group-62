package models.Enums;

public enum Weather {
    Sunny,Rainy,Storm,Snowy;
}
