package models.Enums;

public enum WeekDays {
    Sunday,Monday,Tuesday,Wednesday,Thursday,Friday,Saturday;
    private int time;
    public int getTime(){
        return time;
    }
    public void setTime(int time){
        this.time = time;
    }
    public void changeDay(){

    }
    public void changeTime(){

    }
}
