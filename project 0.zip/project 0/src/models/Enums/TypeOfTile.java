package models.Enums;

public enum TypeOfTile {
    Soil,Water,Grass,Stone;
}
