package models.Enums;

public enum Season {
    Spring,Summer,Autumn,Winter;
}
