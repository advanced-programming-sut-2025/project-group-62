package models.Enums;

public enum Recipe {
}
