package models.Enums;

public enum Request {
}
