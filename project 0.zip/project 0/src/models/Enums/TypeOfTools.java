package models.Enums;

public enum TypeOfTools {
    Shear,
    WateringCan,
    PickAxe,
    MilkPail,
    Hoe,
    Backpack,
    FishingPole,
    Scythe,
    Axe;
}
