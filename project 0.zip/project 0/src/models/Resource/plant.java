package models.Resource;

public class plant extends Resource {
}
