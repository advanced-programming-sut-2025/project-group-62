package models.Resource;

public class Tree extends Resource {
}
