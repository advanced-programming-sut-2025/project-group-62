package models.Resource;

public class Soil extends Resource {
}
