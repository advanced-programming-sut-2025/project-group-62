package models.Resource;

public abstract class Resource {
}
