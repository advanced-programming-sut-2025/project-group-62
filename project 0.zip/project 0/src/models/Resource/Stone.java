package models.Resource;

public class Stone extends Resource {
}
