package models.map;

public class Map {
    Tile[][] tiles;
}
