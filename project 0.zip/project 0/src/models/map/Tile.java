package models.map;

import models.Enums.Weather;
import models.Resource.Resource;

public class Tile {
    int x;
    int y;
    private Resource resource;
    Weather weather;
}
