package models;

import models.User.Player;
import models.map.Map;

import java.util.ArrayList;

public class Game {
    private Map map;
    private ArrayList<Player> players;
    private Date date;
}
