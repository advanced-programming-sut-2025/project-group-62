package models;

import models.Enums.Season;
import models.Enums.WeekDays;

public class Date {
    Season season;
    WeekDays weekDay;
}
