package models.Animal;

public class Rabbit extends Animal{
}
