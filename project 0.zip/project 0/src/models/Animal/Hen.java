package models.Animal;

public class Hen extends Animal{
}
