package models.Animal;

public class Duck extends Animal{
}
