package models.Animal;

public class Dinosaur extends Animal{
}
