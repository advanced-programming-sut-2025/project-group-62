package models.Animal.Fish;

import models.Enums.Season;

public class Fish {
    private String name;
    private int price;
    private Season season;
}
