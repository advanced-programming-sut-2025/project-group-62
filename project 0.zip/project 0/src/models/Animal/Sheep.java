package models.Animal;

public class Sheep extends Animal{
}
