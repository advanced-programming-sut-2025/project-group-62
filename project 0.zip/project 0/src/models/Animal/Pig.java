package models.Animal;

public class Pig extends Animal{
}
