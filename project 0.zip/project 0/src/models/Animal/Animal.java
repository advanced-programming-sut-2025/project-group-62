package models.Animal;

import models.User.Player;

import java.util.ArrayList;

public abstract class Animal {
    private static final ArrayList<Animal> animals = new ArrayList<Animal>();
    private int hunger;
    private Player owner;
    public void pet(){

    }
    public void feed(){

    }
}
