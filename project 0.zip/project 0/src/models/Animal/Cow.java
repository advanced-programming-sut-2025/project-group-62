package models.Animal;

public class Cow extends Animal{
}
