package models.Animal;

public class Goat extends Animal{
}
