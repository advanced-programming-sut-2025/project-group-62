package views;

public class TradingPage {
}
